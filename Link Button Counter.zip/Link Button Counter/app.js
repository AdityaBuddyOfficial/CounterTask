
const counter=document.getElementById("counterId");
const btn=document.getElementById("btn");
const link=document.getElementById("linkId");


let count=0;

function countingClick(){
    count++;
    counter.innerText=count;
    counter.style.color="red";
}



btn.addEventListener('click',()=>{
    countingClick();
})


link.addEventListener('click',()=>{
    countingClick();
})